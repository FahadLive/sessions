extends Node2D

# STEP 1: replace this file with the code from the guide.
