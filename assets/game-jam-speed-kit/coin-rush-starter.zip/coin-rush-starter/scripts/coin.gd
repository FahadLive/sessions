extends Area2D

# STEP 1: replace this file with the code from the guide.
func _on_body_entered(_body: Node2D) -> void:
	pass
