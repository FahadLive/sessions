extends CharacterBody2D

# STEP 1: replace this file with the code from the guide.
