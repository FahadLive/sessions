COIN RUSH - ASSET PACK
======================
Ready-made art, sound and a font for the Game Jam Speed Kit, so you can
practise importing without hunting for files first.

  art/     tiny_dungeon_tilemap.png  (12 x 11 grid of 16px tiles)
           coin_spin.png             (4 frames, 16px each, for AnimatedSprite2D)
  audio/   sfx_coin.wav  sfx_hit.wav  sfx_win.wav   short effects (WAV)
           music_level1.ogg                          a looping-style track (OGG)
  ui/      KenneyPixel.ttf                           pixel font

All CC0. Details in CREDITS-lines.txt and licenses/.
Step 3 of the guide shows you how to drag these into Godot.
